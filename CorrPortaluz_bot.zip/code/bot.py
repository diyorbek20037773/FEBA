# from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
# from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder


# from aiogram import Bot, Dispatcher
# import asyncio

# from aiogram import F, Router
# from aiogram.types import Message , CallbackQuery, ReplyKeyboardRemove
# from aiogram.filters import CommandStart, Command

# router=Router()


# language=["O'zbekcha🇺🇿","Русский🇷🇺"]
# async def languages():
#     keyboard=ReplyKeyboardBuilder()
#     for lang in language:
#         keyboard.add(KeyboardButton(text=lang))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)


# Menu1=["Huquqiy asoslar📄","Namuna va sinamalar olish normalari👕👚", "Kerakli asbob va jihozlar:🛠️","E'tiborli jihatlar🔐",]
# async def main_menu1():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in Menu1:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="Tilni o'zgartirish🇺🇿➡️🇷🇺"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# Menu2=["Правовые основы📄", "Нормы отбора проб и испытаний👕👚","Необходимые инструменты и оборудование: 🛠️", "Основные моменты🔐"]
# async def main_menu2():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in Menu2:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="Изменить язык🇷🇺➡️🇺🇿"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)





# tn1=["50-guruh", "51-guruh","52-guruh", "53-guruh","54-guruh", "55-guruh","56-guruh", "57-guruh","58-guruh", "59-guruh","60-guruh", "61-guruh","62-guruh","63-guruh"]
# async def ten1():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tn1:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Asosiy menu"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)




# tn2=["Группа №50", "Группа №51","Группа №52", "Группа №53","Группа №54", "Группа №55","Группа №56", "Группа №57","Группа №58", "Группа №59","Группа №60", "Группа №61","Группа №62","Группа №63"]
# async def ten2():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tn2:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Главное меню"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)



# tob505=["Волокна","Волос","Отходы","Пряжа","Нити","Нитки швейные","Бечевки","Веревки","Ткани"]
# async def tobb505():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob505:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)



# tob56=["Пряжа","Нити","Нитки швейные","Бечевки","Веревки","Вата","Войлок или фетр","Нетканые материалы","Сетки и сети","Готовые рыболовные сети","Изделия из нитей или пряжи"]
# async def tobb56():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob56:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)


# tob57=["Ковры","Текстильные напольные покрытия"]
# async def tobb57():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob57:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tob58=["Специальные ткани","Тафтинговые текстильные материалы","Кружева","Гобелены","Вышивки","Узкие ткани"]
# async def tobb58():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob58:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tob59=["Текстильные материалы, просмоленные или накрахмаленные, используемые для изготовления книжных переплетов или аналогичных целей","Калька","Загрунтованный холст для живописи","Бортовка и аналогичные жесткие текстильные материалы для каркасов шляп","Материалы кордные для шин","Линолеум","Настенные покрытия из текстильных материалов","Текстильные материалы прорезиненные","Текстильные фитили, шланги","Текстильные материалы, пропитанные, с покрытием или дублированные пластмассами","Ленты конвейерные или ремни приводные, или бельтинг, из текстильных материалов, пропитанных или непропитанных","Текстильные материалы для технических целей"]
# async def tobb59():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob59:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tob60=["Трикотажные полотна"]
# async def tobb60():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob60:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tob612=["Предметы одежды и принадлежности к одежде трикотажные, кроме трикотажных","Прочие готовые текстильные изделия"]
# async def tobb612():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob612:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tob63=["Предметы одежды и принадлежности к одежде трикотажные, кроме трикотажных","Прочие готовые текстильные изделия","Одежда и прочие изделия, бывшие в употреблении"]
# async def tobb63():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob63:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


















# tov505=["Tolalar","Tuklar","Chiqindilar","Iplar","Tikuv iplari","Arqonlar","Matolar","Boshqalar"]
# async def tovv505():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov505:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)



# tov56=["Iplar","Tikuv iplari","Arqonlar","Vata","Kigiz yoki fetr","Noto'qima materiallar","Tarmoqlar va tayyor baliq ovlash to'rlari"]
# async def tovv56():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov56:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)


# tov57=["Gilamlar","Boshqa to'qimachilik qoplamalari"]
# async def tovv57():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov57:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tov58=["Maxsus matolar","Krujva","Gobelen","Boshqa"]
# async def tovv58():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov58:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tov59=["Plastik qoplamali matolar","Texnik to'qimachilik materiallari","Konveyer tasmalari ","Texnik maqsadlar uchun matolar"]
# async def tovv59():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov59:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tov60=["Trikotaj matolar"]
# async def tovv60():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov60:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tov612=["Kiyim-kechak","Tayyor to'qimachilik mahsulotlari"]
# async def tovv612():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov612:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tov63=["Kiyim-kechak","Tayyor to'qimachilik mahsulotlari","Foydalanilgan kiyim-kechak"]
# async def tovv63():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov63:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)





# salom="""
# 🤖 Аssalom aleykum hurmatli bot foydalanuvchisi!

# Ushbu bot sizga To'qimachilik mahsulotlaridan namuna va sinama olish normalari bo'yicha ma'lumotlar olishda yordam beradi. Barcha ma'lumotlar tavsiyaviy xarakterga ega.

# Botdan foydalanish tilini tanlang 👇

# ➖➖➖➖➖➖➖➖➖

# 🤖 Привет уважаемый пользователь нашего бота!

# Этот бот помогает вам получить информацию об образцах и нормах отбора проб из текстильных изделий. Вся информация имеют рекомендательный характер.

# Выберите язык для использования бота 👇"""

# @router.message(CommandStart())
# async def cmd_start(message: Message):
#     await message.answer(text=salom, reply_markup=await  languages())



# @router.message(F.text == "O'zbekcha🇺🇿")
# async def catalog(message: Message):
#     await message.answer("Quyidagi bo'limlardan birini tanlang...", reply_markup=await  main_menu1())
    
# @router.message(F.text == "Tilni o'zgartirish🇺🇿➡️🇷🇺")
# async def catalog(message: Message):
#     await message.answer(text=salom,reply_markup=await  languages())

    
    
    
# @router.message(F.text == "Русский🇷🇺")
# async def catalog(message: Message):
#     await message.answer("Пожалуйста, выберите один из разделов ниже...", reply_markup=await  main_menu2())
    
# @router.message(F.text == "Изменить язык🇷🇺➡️🇺🇿")
# async def catalog(message: Message):
#     await message.answer(text=salom,reply_markup=await  languages())
    
    
# @router.message(F.text == "Namuna va sinamalar olish normalari👕👚")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovar guruhini tanlang...", reply_markup=await  ten1())
    
# @router.message(F.text == "Нормы отбора проб и испытаний👕👚")
# async def catalog(message: Message):
#     await message.answer("Выберите нужную группу товаров...", reply_markup=await  ten2())


# @router.message(F.text == "⬅️Asosiy menu")
# async def catalog(message: Message):
#     await message.answer("Quyidagi bo'limlardan birini tanlang...", reply_markup=await  main_menu1())

# @router.message(F.text == "⬅️Главное меню")
# async def catalog(message: Message):
#     await message.answer("Пожалуйста, выберите один из разделов ниже...", reply_markup=await  main_menu2())



# @router.message(F.text == "Huquqiy asoslar📄")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 O'zbekiston Respublikasi Vazirlar Mahkamasining 17-mart 2021- yildagi 145-son qarori.
# Havola: https://lex.uz/uz/docs/-5336511""")
#     await message.answer(text="""
# 👉 ISO 1130 To'qimachilik tolalaridan sinov uchun namunalar olishning ba'zi usullari to'g'risida.

# 👉 ISO 5086 To'qimachilik pol qoplamalari va qo'l bilan to'qilgan gilamlardan sinov uchun namunalar olish va hududlarni tanlash to'g'risida.

# 👉 EN 12751 To'qimachilik tolalari, iplari va matolaridan sinov uchun namunalar olish to'g'risida.""")
  
#     # await message.answer("bq buyruq")

# @router.message(F.text == "Правовые основы📄")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 Постановление Кабинета Министров Республики Узбекистан №145 от 17.03.2021.
# Ссылка: https://lex.uz/uz/docs/-5336511""")
#     await message.answer("""
# 👉 ISO 1130 О некоторых методах отбора проб для испытаний из текстильных волокон.

# 👉 ISO 5086 Об отборе проб и выборе участков для испытаний текстильных напольных покрытий и ковров ручной работы.

# 👉 EN 12751 О взятии проб для испытаний текстильных волокон, пряжи и тканей.""")
#     # await message.answer("bq buyruq")



# @router.message(F.text == "Kerakli asbob va jihozlar:🛠️")
# async def catalog(message: Message):
#     await message.answer("""
# Kerakli asbob va jihozlar:🛠️⚙️
# 👉 Maxsus qo'lqop 
# 👉 Ko'zoynak (agar zarur bo'lsa)
# 👉 Matoga mo'ljallangan qaychi – zich va qalin matolarni oson kesish uchun
# 👉 Pinset – kichik yoki nozik namunalarni olishda foydalanish uchun
# 👉 Steril idishlar yoki paketlar – namunalarni tozaligini ta'minlash uchun
# 👉 Maxsus qadoq - almashtirib qo'yilishining oldini olingan holda yorliq yoki o'ramni butunligini ta'minlash uchun

# Izoh: Pichoq ishlatish tavsiya etilmaydi. Chunki bu quyidagi kamchiliklarni keltirib chiqarishi mumkin:
# - Materialga zarar yetkazish.
# - Aniqlikning pastligi.
# - Tolalarning buzilishi.
# - Jarohat xavfi.
# - Qalin matolar uchun mos kelmaslik.
# - Ish samaradorligining pasayishi.
# - Asbobning tez eskirishi.
# - Tekislikni buzishi.""")
    
    
    
# @router.message(F.text == "E'tiborli jihatlar🔐")
# async def catalog(message: Message):    
#     await message.answer("""
#  Ehtiyotkor bo'ling❗️
#  Zararli moddalarni o'z ichiga olgan to'qimachilik mahsulotlari quyidagilar bo'lishi ehtimoldan xoli emas:

# 1. Kimyoviy moddalarga to'yingan mahsulotlar: formaldegid, azo-bo'yoqlar, pestitsidlar;  
# 2. Olovga bardoshli qilib ishlov berilgan mahsulotlar: toksik moddalarni ajratib chiqarishi mumkin;  
# 3. Kimyoviy bo'yoqlar bilan bo'yalgan matolar: allergiya yoki teri kasalliklarini keltirib chiqarishi mumkin;  
# 4. Sintetik materiallar: zararli moddalar ajratishi yoki elektr statikani yig'ishi mumkin.  
# 5. Mikroblar yoki zamburug'lar bilan ifloslangan matolar.  
# 6. Ifloslangan mahsulotlar: xavfli biologik yoki radioaktiv moddalarni o'zida jamlagan bo'lishi mumkin;  
# 7. Tarkibida zararli metall tolalari bo'lgan materiallar (masalan, og'ir metallar).  
# 8. Xavfli chang yoki tolalarni ajratib chiqaradigan mahsulotlar: nafas olish muammolariga sabab bo'lishi mumkin.  

# Bunday mahsulotlardan namuna va sinama olishda maxsus ehtiyot choralarini ko'rish va xalqaro standartlarga rioya qilish muhimdir.""")

# @router.message(F.text == "Основные моменты🔐")
# async def catalog(message: Message):
#     await message.answer("""
# Будьте осторожны❗️
# Текстильные изделия, содержащие вредные вещества, скорее всего:  

# 1. Продукты, насыщенные химическими веществами: формальдегидом, азокрасителями, пестицидами;  
# 2. Огнестойкие продукты переработки могут выделять токсичные вещества.  
# 3. Ткани, окрашенные химическими красителями, с возможностью возникновения аллергии или кожных заболеваний.  
# 4. Синтетические материалы могут выделять вредные вещества или собирать статическое электричество.  
# 5. Ткани, загрязненные микробами или грибками.  
# 6. Загрязненная продукция, содержащая опасные биологические или радиоактивные вещества.  
# 7. Материалы, содержащие вредные металлические волокна (например, тяжелые металлы).  
# 8. Продукты, выделяющие опасную пыль или волокна, могут вызвать проблемы с дыханием.  

# Важно принимать особые меры предосторожности и придерживаться международных стандартов при отборе проб и тестировании таких продуктов.
# """)


# @router.message(F.text == "Необходимые инструменты и оборудование: 🛠️")
# async def catalog(message: Message):    
#     await message.answer("""
# Необходимые инструменты и оборудование: 🛠️⚙️
# 👉 Специальные перчатки
# 👉 Очки (при необходимости)
# 👉 Ножницы для ткани – для удобного разрезания плотных и толстых тканей
# 👉 Пинцет – для взятия небольших или деликатных образцов
# 👉 Стерильные контейнеры или пакеты – для обеспечения чистоты проб
# 👉 Специальная упаковка – для обеспечения целостности этикетки или упаковки, не допускающей замены

# Примечание. Не рекомендуется использовать нож. Потому что это может вызвать следующие недостатки:
# - Повреждение материала.
# - Низкое разрешение.
# - Разрушение волокон.
# - Риск получения травмы.
# - Не подходит для плотных тканей.
# - Снижение эффективности работы.
# - Быстрый износ инструмента.
# - Нарушение самолета.""")





# @router.message(F.text == "Группа №50")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb505())

# @router.message(F.text == "Группа №51")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb505())
    
# @router.message(F.text == "Группа №52")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb505())

# @router.message(F.text == "Группа №53")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb505())

# @router.message(F.text == "Группа №54")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb505())
    
# @router.message(F.text == "Группа №55")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb505())
    
# @router.message(F.text == "Группа №56")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb56())

# @router.message(F.text == "Группа №57")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb57())
    
# @router.message(F.text == "Группа №58")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb58())
    
# @router.message(F.text == "Группа №59")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb59())

# @router.message(F.text == "Группа №60")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb60())
    
# @router.message(F.text == "Группа №61")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb612())
    
# @router.message(F.text == "Группа №62")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb612())

# @router.message(F.text == "Группа №63")
# async def catalog(message: Message):
#     await message.answer("Выберите нужный товар...", reply_markup=await  tobb63())
    


# @router.message(F.text == "⬅️Назад")
# async def catalog(message: Message):
#     await message.answer("Выберите нужную группу товаров...", reply_markup=await  ten2())


# @router.message(F.text == "Волокна")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) по 100 г,
# 👉 3 пробы (образца) формата A4 (297 на 210 мм) при поставках товара в кипах
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANmZ260SehmBq0bUbVD2D8v2CQ9zoIAAl_pMRunanhLRybRvhboAdEBAAMCAAN4AAM2BA") 
#     await message.answer_photo(photo="AgACAgIAAxkBAANkZ260G_Uu6OaS3VfJ9v4eBAh_QcgAAgfpMRsj-HlLFnCORbzg1-wBAAMCAAN4AAM2BA")


# @router.message(F.text == "Волос")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) по 100 г,
# 👉 3 пробы (образца) формата A4 (297 на 210 мм) при поставках товара в кипах
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANmZ260SehmBq0bUbVD2D8v2CQ9zoIAAl_pMRunanhLRybRvhboAdEBAAMCAAN4AAM2BA") 
#     await message.answer_photo(photo="AgACAgIAAxkBAANkZ260G_Uu6OaS3VfJ9v4eBAh_QcgAAgfpMRsj-HlLFnCORbzg1-wBAAMCAAN4AAM2BA")

    
# @router.message(F.text == "Отходы")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) по 100 г,
# 👉 3 пробы (образца) формата A4 (297 на 210 мм) при поставках товара в кипах
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANmZ260SehmBq0bUbVD2D8v2CQ9zoIAAl_pMRunanhLRybRvhboAdEBAAMCAAN4AAM2BA") 
#     await message.answer_photo(photo="AgACAgIAAxkBAANkZ260G_Uu6OaS3VfJ9v4eBAh_QcgAAgfpMRsj-HlLFnCORbzg1-wBAAMCAAN4AAM2BA")

    
# @router.message(F.text == "Пряжа")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) (бобина, катушка, моток, др.) без нарушения целостности упаковки, с маркировкой, при весе образца не более 1000 г.
# 👉 При весе образца более 1000 г - 3 пробы нити по 10 м, намотанные на сердечник или шпулю
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANiZ26z804lEEczeDTlYSUf7rFzUbUAAmnpMRunanhLgDeLdzoXBF8BAAMCAAN4AAM2BA")
#     await message.answer_photo(photo="AgACAgIAAxkBAANgZ26zwOIQUz3gVvsXDi18BHf82OYAAmbpMRunanhLY0vIA6DFRocBAAMCAAN4AAM2BA")
    
    
# @router.message(F.text == "Нити")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) (бобина, катушка, моток, др.) без нарушения целостности упаковки, с маркировкой, при весе образца не более 1000 г.
# 👉 При весе образца более 1000 г - 3 пробы нити по 10 м, намотанные на сердечник или шпулю
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANiZ26z804lEEczeDTlYSUf7rFzUbUAAmnpMRunanhLgDeLdzoXBF8BAAMCAAN4AAM2BA")
#     await message.answer_photo(photo="AgACAgIAAxkBAANgZ26zwOIQUz3gVvsXDi18BHf82OYAAmbpMRunanhLY0vIA6DFRocBAAMCAAN4AAM2BA")
    
    
    
# @router.message(F.text == "Нитки швейные")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) (бобина, катушка, моток, др.) без нарушения целостности упаковки, с маркировкой, при весе образца не более 1000 г.
# 👉 При весе образца более 1000 г - 3 пробы нити по 10 м, намотанные на сердечник или шпулю
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANiZ26z804lEEczeDTlYSUf7rFzUbUAAmnpMRunanhLgDeLdzoXBF8BAAMCAAN4AAM2BA")
#     await message.answer_photo(photo="AgACAgIAAxkBAANgZ26zwOIQUz3gVvsXDi18BHf82OYAAmbpMRunanhLY0vIA6DFRocBAAMCAAN4AAM2BA")
    
    
    
# @router.message(F.text == "Бечевки")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) (бобина, катушка, моток, др.) без нарушения целостности упаковки, с маркировкой, при весе образца не более 1000 г.
# 👉 При весе образца более 1000 г - 3 пробы нити по 10 м, намотанные на сердечник или шпулю
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANiZ26z804lEEczeDTlYSUf7rFzUbUAAmnpMRunanhLgDeLdzoXBF8BAAMCAAN4AAM2BA")
#     await message.answer_photo(photo="AgACAgIAAxkBAANgZ26zwOIQUz3gVvsXDi18BHf82OYAAmbpMRunanhLY0vIA6DFRocBAAMCAAN4AAM2BA")
    
    
    
# @router.message(F.text == "Веревки")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) (бобина, катушка, моток, др.) без нарушения целостности упаковки, с маркировкой, при весе образца не более 1000 г.
# 👉 При весе образца более 1000 г - 3 пробы нити по 10 м, намотанные на сердечник или шпулю
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANiZ26z804lEEczeDTlYSUf7rFzUbUAAmnpMRunanhLgDeLdzoXBF8BAAMCAAN4AAM2BA")
#     await message.answer_photo(photo="AgACAgIAAxkBAANgZ26zwOIQUz3gVvsXDi18BHf82OYAAmbpMRunanhLY0vIA6DFRocBAAMCAAN4AAM2BA")
    
    
    
# @router.message(F.text == "Ткани")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")

# @router.message(F.text == "Вата")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Войлок или фетр")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Нетканые материалы")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Сетки и сети")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Готовые рыболовные сети")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Изделия из нитей или пряжи")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")



# @router.message(F.text == "Ковры")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 1 готовое крупногабаритное изделие (площадью не более 6 кв. м) либо
# 👉 3 пробы (образца) изделий (в виде пластин максимальной площадью 0,3 кв. м);
# 👉 в случае рулонных напольных покрытий - 3 пробы (образца) длиной 50 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAAMzZ26yqLM1_OlGDm3VB3foxa7MYscAAprpMRunanhLL0e6KW_iyqIBAAMCAANtAAM2BA")
    




# @router.message(F.text == "Текстильные напольные покрытия")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 1 готовое крупногабаритное изделие (площадью не более 6 кв. м) либо
# 👉 3 пробы (образца) изделий (в виде пластин максимальной площадью 0,3 кв. м);
# 👉 в случае рулонных напольных покрытий - 3 пробы (образца) длиной 50 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAAMzZ26yqLM1_OlGDm3VB3foxa7MYscAAprpMRunanhLL0e6KW_iyqIBAAMCAANtAAM2BA")



# @router.message(F.text == "Специальные ткани")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)или 3 образца готовых изделий
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")



# @router.message(F.text == "Тафтинговые текстильные материалы")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)или 3 образца готовых изделий
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")

# @router.message(F.text == "Кружева")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)или 3 образца готовых изделий
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Гобелены")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)или 3 образца готовых изделий
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")

# @router.message(F.text == "Вышивки")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)или 3 образца готовых изделий
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Узкие ткани")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)или 3 образца готовых изделий
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Текстильные материалы, просмоленные или накрахмаленные, используемые для изготовления книжных переплетов или аналогичных целей")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")

# @router.message(F.text == "Калька")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")
    
# @router.message(F.text == "Загрунтованный холст для живописи")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")
    
# @router.message(F.text =="Бортовка и аналогичные жесткие текстильные материалы для каркасов шляп")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")
    
# @router.message(F.text == "Материалы кордные для шин")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")
    
# @router.message(F.text == "Линолеум")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")
    
# @router.message(F.text == "Настенные покрытия из текстильных материалов")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")
    
# @router.message(F.text == "Текстильные материалы прорезиненные")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")

# @router.message(F.text == "Текстильные фитили, шланги")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")

# @router.message(F.text == "Текстильные материалы, пропитанные, с покрытием или дублированные пластмассами")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")

# @router.message(F.text == "Ленты конвейерные или ремни приводные, или бельтинг, из текстильных материалов, пропитанных или непропитанных")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# 👉 3 образца готовых изделий в полной комплектации
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")

# @router.message(F.text == "Текстильные материалы для технических целей")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# 👉 3 образца готовых изделий в полной комплектации
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Трикотажные полотна")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) длиной 20-30 см на всю ширину рулона (с кромками)
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Предметы одежды и принадлежности к одежде трикотажные, кроме трикотажных")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) изделий каждого наименования и артикула
# """)


# @router.message(F.text == "Прочие готовые текстильные изделия")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 пробы (образца) изделий каждого наименования и артикула
# """)


# @router.message(F.text == "Одежда и прочие изделия, бывшие в употреблении")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 Выборочно - не менее 5 образцов изделий разных наименований из 10% разных грузовых мест
# """)











# @router.message(F.text == "50-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv505())
    
    
# @router.message(F.text == "51-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv505())
    
    
# @router.message(F.text == "52-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv505())
    
    
# @router.message(F.text == "53-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv505())


# @router.message(F.text == "54-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv505())
    
    
# @router.message(F.text == "55-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv505())
    
    
# @router.message(F.text == "56-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv56())
    
    
# @router.message(F.text == "57-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv57())


# @router.message(F.text == "58-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv58())
    
    
# @router.message(F.text == "59-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv59())
    
    
# @router.message(F.text == "60-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv60())
    
    
# @router.message(F.text == "61-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv612())


# @router.message(F.text == "62-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv612())
    
    
# @router.message(F.text == "63-guruh")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovarni tanlang...", reply_markup=await  tovv63())
    
    
# @router.message(F.text == "⬅️Orqaga")
# async def catalog(message: Message):
#     await message.answer("Kerakli tovar guruhini tanlang...", reply_markup=await  ten1())





# @router.message(F.text == "Tolalar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar (100 g har biridan)
# 👉 3 ta A4 formatida (297 x 210 mm) namunalar, agar mahsulot kipalarda (to'plamlarda) yetkazib berilgan bo'lsa.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANmZ260SehmBq0bUbVD2D8v2CQ9zoIAAl_pMRunanhLRybRvhboAdEBAAMCAAN4AAM2BA") 
#     await message.answer_photo(photo="AgACAgIAAxkBAANkZ260G_Uu6OaS3VfJ9v4eBAh_QcgAAgfpMRsj-HlLFnCORbzg1-wBAAMCAAN4AAM2BA") 


# @router.message(F.text == "Tuklar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar (100 g har biridan)
# 👉 3 ta A4 formatida (297 x 210 mm) namunalar, agar mahsulot kipalarda (to'plamlarda) yetkazib berilgan bo'lsa.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANmZ260SehmBq0bUbVD2D8v2CQ9zoIAAl_pMRunanhLRybRvhboAdEBAAMCAAN4AAM2BA")  
#     await message.answer_photo(photo="AgACAgIAAxkBAANkZ260G_Uu6OaS3VfJ9v4eBAh_QcgAAgfpMRsj-HlLFnCORbzg1-wBAAMCAAN4AAM2BA")

    
# @router.message(F.text == "Chiqindilar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar (100 g har biridan)
# 👉 3 ta A4 formatida (297 x 210 mm) namunalar, agar mahsulot kipalarda (to'plamlarda) yetkazib berilgan bo'lsa.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANmZ260SehmBq0bUbVD2D8v2CQ9zoIAAl_pMRunanhLRybRvhboAdEBAAMCAAN4AAM2BA")  
#     await message.answer_photo(photo="AgACAgIAAxkBAANkZ260G_Uu6OaS3VfJ9v4eBAh_QcgAAgfpMRsj-HlLFnCORbzg1-wBAAMCAAN4AAM2BA")

    
# @router.message(F.text == "Matolar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan. 
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")
    
# @router.message(F.text == "Iplar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar (bobina, g'altak yoki to'qim) qadoqlangan holda, yaroqsiz holga keltirmasdan. Namuna vazni 1000 g dan oshmasa.
# 👉 Agar namunalar vazni 1000 g dan oshsa, 3 ta ip namunasi, uzunligi 10 m, g'altakka yoki asosga o'ralgan holda. 
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANiZ26z804lEEczeDTlYSUf7rFzUbUAAmnpMRunanhLgDeLdzoXBF8BAAMCAAN4AAM2BA")
#     await message.answer_photo(photo="AgACAgIAAxkBAANgZ26zwOIQUz3gVvsXDi18BHf82OYAAmbpMRunanhLY0vIA6DFRocBAAMCAAN4AAM2BA")
    
    
    
# @router.message(F.text == "Tikuv iplari")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar (bobina, g'altak yoki to'qim) qadoqlangan holda, yaroqsiz holga keltirmasdan. Namuna vazni 1000 g dan oshmasa.
# 👉 Agar namunalar vazni 1000 g dan oshsa, 3 ta ip namunasi, uzunligi 10 m, g'altakka yoki asosga o'ralgan holda. 
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANiZ26z804lEEczeDTlYSUf7rFzUbUAAmnpMRunanhLgDeLdzoXBF8BAAMCAAN4AAM2BA")
#     await message.answer_photo(photo="AgACAgIAAxkBAANgZ26zwOIQUz3gVvsXDi18BHf82OYAAmbpMRunanhLY0vIA6DFRocBAAMCAAN4AAM2BA")
    
    
    
# @router.message(F.text == "Arqonlar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar (bobina, g'altak yoki to'qim) qadoqlangan holda, yaroqsiz holga keltirmasdan. Namuna vazni 1000 g dan oshmasa.
# 👉 Agar namunalar vazni 1000 g dan oshsa, 3 ta ip namunasi, uzunligi 10 m, g'altakka yoki asosga o'ralgan holda.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANiZ26z804lEEczeDTlYSUf7rFzUbUAAmnpMRunanhLgDeLdzoXBF8BAAMCAAN4AAM2BA")
#     await message.answer_photo(photo="AgACAgIAAxkBAANgZ26zwOIQUz3gVvsXDi18BHf82OYAAmbpMRunanhLY0vIA6DFRocBAAMCAAN4AAM2BA")
    
    
# @router.message(F.text == "Boshqalar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar (bobina, g'altak yoki to'qim) qadoqlangan holda, yaroqsiz holga keltirmasdan. Namuna vazni 1000 g dan oshmasa.
# 👉 Agar namunalar vazni 1000 g dan oshsa, 3 ta ip namunasi, uzunligi 10 m, g'altakka yoki asosga o'ralgan holda.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANiZ26z804lEEczeDTlYSUf7rFzUbUAAmnpMRunanhLgDeLdzoXBF8BAAMCAAN4AAM2BA")
#     await message.answer_photo(photo="AgACAgIAAxkBAANgZ26zwOIQUz3gVvsXDi18BHf82OYAAmbpMRunanhLY0vIA6DFRocBAAMCAAN4AAM2BA")
    
    
# @router.message(F.text == "Vata")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")
    
# @router.message(F.text == "Kigiz yoki fetr")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")
    
# @router.message(F.text == "Noto'qima materiallar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")
    
# @router.message(F.text == "Tarmoqlar va tayyor baliq ovlash to'rlari")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, tayyor mahsulotlar to'liq konfiguratsiyada.
# """) 
    
    
# @router.message(F.text == "Gilamlar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 1 ta katta hajmdagi tayyor mahsulot (maydoni 6 kv. metrdan oshmasligi kerak) yoki
# 👉 3 ta namunalar (0,3 kv. m maydonga ega plitalar ko'rinishida).
# 👉 Agar rulon ko'rinishidagi mahsulot bo'lsa, 3 ta namunalar, uzunligi 50 sm rulonning to'liq kengligi bilan.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAAMzZ26yqLM1_OlGDm3VB3foxa7MYscAAprpMRunanhLL0e6KW_iyqIBAAMCAANtAAM2BA")

# @router.message(F.text == "Boshqa to'qimachilik qoplamalari")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 1 ta katta hajmdagi tayyor mahsulot (maydoni 6 kv. metrdan oshmasligi kerak) yoki
# 👉 3 ta namunalar (0,3 kv. m maydonga ega plitalar ko'rinishida).
# 👉 Agar rulon ko'rinishidagi mahsulot bo'lsa, 3 ta namunalar, uzunligi 50 sm rulonning to'liq kengligi bilan.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAAMzZ26yqLM1_OlGDm3VB3foxa7MYscAAprpMRunanhLL0e6KW_iyqIBAAMCAANtAAM2BA")


# @router.message(F.text == "Maxsus matolar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan
# 👉 3 ta tayyor mahsulot namunasi.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Krujva")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan
# 👉 3 ta tayyor mahsulot namunasi.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Gobelen")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan
# 👉 3 ta tayyor mahsulot namunasi.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Boshqa")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan
# 👉 3 ta tayyor mahsulot namunasi.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Plastik qoplamali matolar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")



# @router.message(F.text == "Texnik to'qimachilik materiallari")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")



# @router.message(F.text == "Konveyer tasmalari")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan.
# 👉 3 ta tayyor mahsulot namunasi, to'liq konfiguratsiyada.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")



# @router.message(F.text == "Texnik maqsadlar uchun matolar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan.
# 👉 3 ta tayyor mahsulot namunasi, to'liq konfiguratsiyada.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Trikotaj matolar")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 3 ta namunalar, uzunligi 20-30 sm, rulonning to'liq kengligi bilan.
# """)
#     await message.answer_photo(photo="AgACAgIAAxkBAANIZ26zSN0WwK36roPcLrM28aus2g4AAmrpMRunanhLmvDgIhHN_F8BAAMCAAN4AAM2BA")


# @router.message(F.text == "Kiyim-kechak")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 Har bir nom va artikuldan 3 ta mahsulot namunasi.
# """)


# @router.message(F.text == "Tayyor to'qimachilik mahsulotlari")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 Har bir nom va artikuldan 3 ta mahsulot namunasi.
# """)

# @router.message(F.text == "Foydalanilgan kiyim-kechak")
# async def catalog(message: Message):
#     await message.answer("""
# 👉 Tanlab olish usulida: 10% turli yuk bo'limlaridan kamida 5 ta mahsulot namunasi.
# """)




# @router.message(F.photo)
# async def handle_photo(message:Message):
#     # Get the file ID of the sent photo
#     photo_id = message.photo[-1].file_id  # The highes
#     await message.answer(f"Here is your photo link: {photo_id}")

    



# async def main():
#     bot= Bot(token="7655572060:AAENEu1_nC7nKWGMI0wAogeGNO45Im6CaZ0")
#     dp=Dispatcher()     
#     dp.include_router(router)
#     await dp.start_polling(bot)
    
    
# if __name__ == "__main__":
#     try:
#         asyncio.run(main())
#     except KeyboardInterrupt:
#         print("Exit")
        
       
       
       


