from aiogram import F, Router
from aiogram.types import Message , CallbackQuery, ReplyKeyboardRemove
from aiogram.filters import CommandStart, Command
import app.keyboards as kb
from aiogram.fsm.state import StatesGroup, State 
from aiogram.fsm.context import FSMContext
import sqlite3

conn = sqlite3.connect('main.db')
cursor = conn.cursor()
# import app.database.requests as rq

ADMINS=1320042846
global score
score=0

router=Router()

class Test(StatesGroup):
    holat0=State()
    holat1=State()
    holat2=State()
    holat3=State()
    holat4=State()
    holat5=State()
    holat6=State()
    holat7=State()
    holat8=State()
    holat9=State()
    holat10=State()
    holat11=State()

    
@router.message(Command("start"))
async def on(message: Message):
    await message.answer("""
Assalom aleykum hurmatli foydalanuvchi. Ushbu bot sizga korrupsiyaga moyillik darajasini aniqlashda yordam beradi.
(Здравствуйте, уважаемый пользователь. Этот бот поможет вам определить уровень коррупции.)

/start -Bot haqida ma'lumot.
(Информация о боте)

/test - Testni boshlash. 
(Запустить тест)""")    

@router.message(Command("test"))
async def Test_on(message: Message, state:FSMContext):
    await state.set_state(Test.holat0)
    await message.answer("""
ID ni kiriting..
(Введите ИД..)""")


@router.message(Test.holat0)
async def two_three(message:Message, state:FSMContext):
    await state.update_data(javob0=message.text)
    global javob0 
    javob0=message.text
    global score
    await state.set_state(Test.holat1)
    await message.answer("""
Poraxo'rlikka qanday qaraysiz?
(Как вы относитесь к взяточничеству?)""", reply_markup=await kb.h1())
    


@router.message(Test.holat1)
async def Test_two(message: Message, state:FSMContext):
    global javob1
    javob1=message.text
    global score
    if javob1=="Salbiy(Отрицательный)":
        score+=0
    elif javob1=="O'rtacha(Средний)":
        score+=1
    elif javob1=="Ijobiy(Позитивный)":
        score+=2
    
    await state.set_state(Test.holat2)
    await message.answer("""
Ba'zi hollarda kichik poralar mumkin, deb o'ylaysizmi?
(Считаете ли вы, что небольшие взятки приемлемы в некоторых случаях?)""", reply_markup=await kb.h2())



@router.message(Test.holat2)
async def two_three(message:Message, state:FSMContext):
    await state.update_data(javob2=message.text)
    global javob2
    javob2=message.text
    global score
    if javob2=="Ha(Да)":
        score+=2
    elif javob2=="Bilmadim(Не знаю)":
        score+=1
    elif javob2=="Yo'q(Нет)":
        score+=0
    
    await state.set_state(Test.holat3)
    await message.answer("""
Pora oluvchi mansabdor shaxslarning axloqiy mas'uliyatini qanday baholaysiz?
(Как вы оцениваете моральную ответственность чиновников, берущих взятки?)""", reply_markup=await kb.h3())
    
    
    
@router.message(Test.holat3)
async def two_three(message:Message, state:FSMContext):
    await state.update_data(javob3=message.text)
    global javob3
    javob3=message.text
    global score
    if javob3=="Past(Низкий)":
        score+=0
    elif javob3=="O'rtacha(Средний)":
        score+=1
    elif javob3=="Yuqori(Высокий)":
        score+=2
    
    await state.set_state(Test.holat4)
    await message.answer("""
Siz uchun shaxsiy manfaat muhimroqmi yoki qonunga rioya qilish?
(Что для вас важнее корысть или соблюдение закона?)""", reply_markup=await kb.h4())
    
    
    
@router.message(Test.holat4)
async def two_three(message:Message, state:FSMContext):
    await state.update_data(javob4=message.text)
    global javob4
    javob4=message.text
    global score
    if javob4=="Qonunga rioya qilish(Соблюдение закона)":
        score+=0
    elif javob4=="Shaxsiy manfaat(Личный интерес)":
        score+=2
    
    await state.set_state(Test.holat5)
    await message.answer("""
O'z manfaati uchun qoidalarni buzishga tayyor bo'lgan odamlarga qanday qaraysiz?
(Как вы относитесь к людям, которые готовы нарушать правила ради собственного блага?)""", reply_markup=await kb.h5())
    
    
    
@router.message(Test.holat5)
async def two_three(message:Message, state:FSMContext):
    await state.update_data(javob5=message.text)
    global javob5
    javob5=message.text
    global score
    if javob5=="Salbiy(Отрицательный)":
        score+=0
    elif javob5=="O'rtacha(Средний)":
        score+=1
    elif javob5=="Ijobiy(Позитивный)":
        score+=2
    
    await state.set_state(Test.holat6)
    await message.answer("""
Mamlakatingizda korrupsiya keng tarqalgan, deb hisoblaysizmi?
(Считаете ли вы, что в вашей стране широко распространена коррупция?)""", reply_markup=await kb.h6())
    
    
    
@router.message(Test.holat6)
async def two_three(message:Message, state:FSMContext):
    await state.update_data(javob6=message.text)
    global javob6
    javob6=message.text
    global score
    if javob6=="Ha(Да)":
        score+=2
    elif javob6=="Bilmadim(Не знаю)":
        score+=1
    elif javob6=="Yo'q(Нет)":
        score+=0
    
    await state.set_state(Test.holat7)
    await message.answer("""
Korrupsiya holatlari haqida xabar beruvchi odamlarga qanday qaraysiz?
(Как вы относитесь к людям, сообщающим о коррупции?)""", reply_markup=await kb.h7())
    
    
    
    
@router.message(Test.holat7)
async def two_three(message:Message, state:FSMContext):
    await state.update_data(javob7=message.text)
    global javob7
    javob7=message.text
    global score
    if javob7=="Salbiy(Отрицательный)":
        score+=2
    elif javob7=="O'rtacha(Средний)":
        score+=1
    elif javob7=="Ijobiy(Позитивный)":
        score+=0
    
    
    await state.set_state(Test.holat8)
    await message.answer("""
Poraxo'rlik jinoyat, deb hisoblaysizmi?
(Считаете ли вы взяточничество преступлением?)""", reply_markup=await kb.h8())

    
    
@router.message(Test.holat8)
async def two_three(message:Message, state:FSMContext):
    await state.update_data(javob8=message.text)
    global javob8
    javob8=message.text
    global score
    if javob8=="Ha(Да)":
        score+=0
    elif javob8=="Bilmadim(Не знаю)":
        score+=1
    elif javob8=="Yo'q(Нет)":
        score+=2
    
    await state.set_state(Test.holat9)
    await message.answer("""
Аksariyat odamlar agar ularga foyda keltirsa, pora berishga tayyor, deb hisoblayman.
(Я считаю, что большинство людей готовы дать взятку, если это им выгодно.)""", reply_markup=await kb.h9())
    
    
    
    
@router.message(Test.holat9)
async def two_three(message:Message, state:FSMContext):
    await state.update_data(javob9=message.text)
    global javob9
    javob9=message.text
    global score
    if javob9=="Ha(Да)":
        score+=2
    elif javob9=="Bilmadim(Не знаю)":
        score+=1
    elif javob9=="Yo'q(Нет)":
        score+=0
    
    await state.set_state(Test.holat10)
    await message.answer("""
Аgar meni ushlab qolishlaridan qo'rqmasam, shaxsiy manfaatim uchun qonunni buzishga tayyorman?
(Готов ли я нарушить закон ради личной выгоды, если не боюсь быть пойманным?)""", reply_markup=await kb.h10())
    
    
    
    
@router.message(Test.holat10)
async def two_three(message:Message, state:FSMContext):
    await state.update_data(javob10=message.text)
    global javob10
    javob10=message.text
    global score
    if javob10=="Ha(Да)":
        score+=2
    elif javob10=="Bilmadim(Не знаю)":
        score+=1
    elif javob10=="Yo'q(Нет)":
        score+=0
    
    await state.set_state(Test.holat11)
    await message.answer("""
Pul dunyoda eng muhim omil, deb hisoblaysizmi?
(Считаете ли вы, что деньги – самый важный фактор в мире?)""", reply_markup=await kb.h11())
    
    
    
    
@router.message(Test.holat11)
async def two_three(message:Message, state:FSMContext):
    await state.update_data(javob11=message.text)
    global javob11
    javob11=message.text
    global score
    if javob11=="Ha(Да)":
        score+=2
    elif javob11=="Bilmadim(Не знаю)":
        score+=1
    elif javob11=="Yo'q(Нет)":
        score+=0
        
    global idd
    idd=message.from_user.id
    
    # if score>=17:
    #     Natija="Qizil(Красный)"
    # elif score>12 and score<16:
    #     Natija="Sariq(Желтый)"
    # else:
    #     Natija="Yashil(Зеленый)"
    import random
    li=["Qizil(Красный)","Sariq(Желтый)", "Yashil(Зеленый)" ]
    Natija=random.choice(li)
    
    
    def insert_data( Num, Telegram, J1, J2, J3, J4, J5, J6, J7, J8, J9, J10, J11, Natija):
        cursor.execute("INSERT INTO user (Num, Telegram, J1, J2, J3, J4, J5, J6, J7, J8, J9, J10, J11, Natija) VALUES (?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?)", (Num, Telegram, J1, J2, J3, J4, J5, J6, J7, J8, J9, J10, J11, Natija))
        conn.commit()
    insert_data(javob0, idd, javob1, javob2, javob3, javob4, javob5, javob6, javob7, javob8, javob9, javob10, javob11, Natija) 
    await state.clear()
    await message.answer("Test o'z nihoyasiga yetdi! (Тест окончено!)")

    
    
    
    
    
    
@router.message(F.text=="/cleandbdbdb")
async def get_all_users(message:Message):
    cursor.execute("DELETE FROM user;")
    conn.commit()
    await message.answer("Baza tozalandi!")


@router.message(F.text=="/allusersss")
async def get_all_users(message:Message):
    cursor.execute("SELECT * FROM user")
    users = cursor.fetchall()
    for user in users:
        print(user)
    
    
    
    
# @router.message(Test.holat4)
# async def two_three(message:Message, state:FSMContext):
#     await state.update_data(javob4=message.text)
#     global javob4
#     javob4=message.text
#     global idd
#     idd=message.from_user.id
#     def insert_data( Num, Telegram, Tarix, Holati, Jinoyat, Yana):
#         cursor.execute("INSERT INTO user (Num, Telegram, Tarix, Holati, Jinoyat, Yana) VALUES (?, ?, ?, ?, ?, ?)", (Num, Telegram, Tarix, Holati, Jinoyat, Yana))
#         conn.commit()
#     insert_data(javob0, idd, javob1, javob2, javob3, javob4) 
#     await state.clear()
#     await message.answer("State finished. You can start again with /start.")
  
  
  
  
  
  

# @router.message(F.text=="/cleandbdbdb")
# async def get_all_users(message:Message):
#     cursor.execute("DELETE FROM user;")
#     conn.commit()
#     await message.answer("Baza tozalandi!")


# @router.message(F.text=="/allusersss")
# async def get_all_users(message:Message):
#     cursor.execute("SELECT * FROM user")
#     users = cursor.fetchall()
#     for user in users:
#         print(user)


























  
# # Function to select data from the database
# def select_data(user_id):
#     cursor.execute("SELECT * FROM your_table_name WHERE user_id = ?", (user_id,))
#     rows = cursor.fetchall()
#     return rows

# # Example usage (replace with actual values)
# data = select_data(12345)
# print(data)

    
    
    
    
    
    
    
    

# @router.message(F.text=="/allusers", user_id=ADMINS)
# async def get_all_users(message: Message):
#     users = db.select_all_users()
#     print(users[0][0])
#     await message.answer(users)








# from aiogram import types
# from aiogram.dispatcher import FSMContext
# from aiogram.dispatcher.filters.builtin import Command
# from loader import dp, db
# from aiogram import Bot, Dispatcher, types
# from aiogram.contrib.fsm_storage.memory import MemoryStorage
# from data import config


# from environs import Env

# ADMINS=12345678,12345677,12345676
# BOT_TOKEN="8125861989:AAHaVrmovRcjB85ZDU4kORXFNxQYuceJy80"

# env = Env()
# env.read_env()

# BOT_TOKEN = env.str("8125861989:AAHaVrmovRcjB85ZDU4kORXFNxQYuceJy80")  # Bot toekn
# ADMINS = env.list("ADMINS")  # adminlar ro'yxati

# bot = Bot(token=config.BOT_TOKEN, parse_mode=types.ParseMode.HTML)
# storage = MemoryStorage()
# dp = Dispatcher(bot, storage=storage)








# import asyncio
# from aiogram import types
# from data.config import ADMINS
# from loader import dp, db, bot

# @dp.message_handler(text="/reklama", user_id=ADMINS)
# async def send_ad_to_all(message: types.Message):
#     users = db.select_all_users()
#     for user in users:
#         user_id = user[0]
#         await bot.send_message(chat_id=user_id, text="@SariqDev kanaliga obuna bo'ling!")
#         await asyncio.sleep(0.05)

# @dp.message_handler(text="/cleandb", user_id=ADMINS)
# async def get_all_users(message: types.Message):
#     db.delete_users()
#     await message.answer("Baza tozalandi!")




