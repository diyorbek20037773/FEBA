from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder


holat1=["Salbiy(Отрицательный)","O'rtacha(Средний)", "Ijobiy(Позитивный)"]
async def h1():
    keyboard=ReplyKeyboardBuilder()
    for h in holat1:
        keyboard.add(KeyboardButton(text=h))
    return keyboard.adjust(1).as_markup(resize_keyboard=True, one_time_keyboard = True)

holat2=["Ha(Да)","Bilmadim(Не знаю)", "Yo'q(Нет)"]
async def h2():
    keyboard=ReplyKeyboardBuilder()
    for h in holat2:
        keyboard.add(KeyboardButton(text=h))
    return keyboard.adjust(1).as_markup(resize_keyboard=True, one_time_keyboard = True)

holat3=["Past(Низкий)","O'rtacha(Средний)", "Yuqori(Высокий)"]
async def h3():
    keyboard=ReplyKeyboardBuilder()
    for h in holat3:
        keyboard.add(KeyboardButton(text=h))
    return keyboard.adjust(1).as_markup(resize_keyboard=True, one_time_keyboard = True)

# , one_time_keyboard = True

holat4=["Shaxsiy manfaat(Личный интерес)","Qonunga rioya qilish(Соблюдение закона)"]
async def h4():
    keyboard=ReplyKeyboardBuilder()
    for h in holat4:
        keyboard.add(KeyboardButton(text=h))
    return keyboard.adjust(1).as_markup(resize_keyboard=True, one_time_keyboard = True)


holat5=["Salbiy(Отрицательный)","O'rtacha(Средний)", "Ijobiy(Позитивный)"]
async def h5():
    keyboard=ReplyKeyboardBuilder()
    for h in holat5:
        keyboard.add(KeyboardButton(text=h))
    return keyboard.adjust(1).as_markup(resize_keyboard=True, one_time_keyboard = True)


holat6=["Ha(Да)","Bilmadim(Не знаю)", "Yo'q(Нет)"]
async def h6():
    keyboard=ReplyKeyboardBuilder()
    for h in holat6:
        keyboard.add(KeyboardButton(text=h))
    return keyboard.adjust(1).as_markup(resize_keyboard=True, one_time_keyboard = True)


holat7=["Salbiy(Отрицательный)","O'rtacha(Средний)", "Ijobiy(Позитивный)"]
async def h7():
    keyboard=ReplyKeyboardBuilder()
    for h in holat7:
        keyboard.add(KeyboardButton(text=h))
    return keyboard.adjust(1).as_markup(resize_keyboard=True, one_time_keyboard = True)


holat8=["Ha(Да)","Bilmadim(Не знаю)", "Yo'q(Нет)"]
async def h8():
    keyboard=ReplyKeyboardBuilder()
    for h in holat8:
        keyboard.add(KeyboardButton(text=h))
    return keyboard.adjust(1).as_markup(resize_keyboard=True, one_time_keyboard = True)


holat9=["Ha(Да)","Bilmadim(Не знаю)", "Yo'q(Нет)"]
async def h9():
    keyboard=ReplyKeyboardBuilder()
    for h in holat9:
        keyboard.add(KeyboardButton(text=h))
    return keyboard.adjust(1).as_markup(resize_keyboard=True, one_time_keyboard = True)


holat10=["Ha(Да)","Bilmadim(Не знаю)", "Yo'q(Нет)"]
async def h10():
    keyboard=ReplyKeyboardBuilder()
    for h in holat10:
        keyboard.add(KeyboardButton(text=h))
    return keyboard.adjust(1).as_markup(resize_keyboard=True, one_time_keyboard = True)



holat11=["Ha(Да)","Bilmadim(Не знаю)", "Yo'q(Нет)"]
async def h11():
    keyboard=ReplyKeyboardBuilder()
    for h in holat11:
        keyboard.add(KeyboardButton(text=h))
    return keyboard.adjust(1).as_markup(resize_keyboard=True, one_time_keyboard = True)

















































# language=["O'zbekcha🇺🇿","Русский🇷🇺"]
# async def languages():
#     keyboard=ReplyKeyboardBuilder()
#     for lang in language:
#         keyboard.add(KeyboardButton(text=lang))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)


# Menu1=["Huquqiy asoslar📄","Namuna va sinamalar olish normalari👕👚", "Kerakli asbob va jihozlar:🛠️","E'tiborli jihatlar🔐",]
# async def main_menu1():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in Menu1:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="Tilni o'zgartirish🇺🇿➡️🇷🇺"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# Menu2=["Правовые основы📄", "Нормы отбора проб и испытаний👕👚","Необходимые инструменты и оборудование: 🛠️", "Основные стороны🔐"]
# async def main_menu2():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in Menu2:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="Изменить язык🇷🇺➡️🇺🇿"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)





# tn1=["50-guruh", "51-guruh","52-guruh", "53-guruh","54-guruh", "55-guruh","56-guruh", "57-guruh","58-guruh", "59-guruh","60-guruh", "61-guruh","62-guruh","63-guruh"]
# async def ten1():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tn1:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Asosiy menu"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)




# tn2=["Группа №50", "Группа №51","Группа №52", "Группа №53","Группа №54", "Группа №55","Группа №56", "Группа №57","Группа №58", "Группа №59","Группа №60", "Группа №61","Группа №62","Группа №63"]
# async def ten2():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tn2:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Главное меню"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)



# tob505=["Волокна","Волос","Отходы","Пряжа","Нити","Нитки швейные","Бечевки","Веревки","Ткани"]
# async def tobb505():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob505:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)



# tob56=["Пряжа","Нити","Нитки швейные","Бечевки","Веревки","Вата","Войлок или фетр","Нетканые материалы","Сетки и сети","Готовые рыболовные сети","Изделия из нитей или пряжи"]
# async def tobb56():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob56:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)


# tob57=["Ковры","Текстильные напольные покрытия"]
# async def tobb57():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob57:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tob58=["Специальные ткани","Тафтинговые текстильные материалы","Кружева","Гобелены","Вышивки","Узкие ткани"]
# async def tobb58():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob58:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tob59=["Текстильные материалы, просмоленные или накрахмаленные, используемые для изготовления книжных переплетов или аналогичных целей","Калька","Загрунтованный холст для живописи","Бортовка и аналогичные жесткие текстильные материалы для каркасов шляп","Материалы кордные для шин","Линолеум","Настенные покрытия из текстильных материалов","Текстильные материалы прорезиненные","Текстильные фитили, шланги","Текстильные материалы, пропитанные, с покрытием или дублированные пластмассами","Ленты конвейерные или ремни приводные, или бельтинг, из текстильных материалов, пропитанных или непропитанных","Текстильные материалы для технических целей"]
# async def tobb59():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob59:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tob60=["Трикотажные полотна"]
# async def tobb60():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob60:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tob612=["Предметы одежды и принадлежности к одежде трикотажные, кроме трикотажных","Прочие готовые текстильные изделия"]
# async def tobb612():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob612:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tob63=["Предметы одежды и принадлежности к одежде трикотажные, кроме трикотажных","Прочие готовые текстильные изделия","Одежда и прочие изделия, бывшие в употреблении"]
# async def tobb63():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tob63:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Назад"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


















# tov505=["Tolalar","Tuklar","Chiqindilar","Iplar","Tikuv iplari","Arqonlar","Matolar","Boshqalar"]
# async def tovv505():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov505:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)



# tov56=["Iplar","Tikuv iplari","Arqonlar","Vata","Kigiz yoki fetr","Noto'qima materiallar","Tarmoqlar va tayyor baliq ovlash to'rlari"]
# async def tovv56():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov56:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(2).as_markup(resize_keyboard=True)


# tov57=["Gilamlar","Boshqa to'qimachilik qoplamalari"]
# async def tovv57():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov57:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tov58=["Maxsus matolar","Krujva","Gobelen","Boshqa"]
# async def tovv58():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov58:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tov59=["Plastik qoplamali matolar","Texnik to'qimachilik materiallari","Konveyer tasmalari ","Texnik maqsadlar uchun matolar"]
# async def tovv59():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov59:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tov60=["Trikotaj matolar"]
# async def tovv60():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov60:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tov612=["Kiyim-kechak","Tayyor to'qimachilik mahsulotlari"]
# async def tovv612():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov612:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)


# tov63=["Kiyim-kechak","Tayyor to'qimachilik mahsulotlari","Foydalanilgan kiyim-kechak"]
# async def tovv63():
#     keyboard=ReplyKeyboardBuilder()
#     for mn in tov63:
#         keyboard.add(KeyboardButton(text=mn))
#     keyboard.add(KeyboardButton(text="⬅️Orqaga"))
#     return keyboard.adjust(1).as_markup(resize_keyboard=True)
















